package com.cg.appl.listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class CreateCardListener
 *
 */
@WebListener
public class CreateCardListener implements ServletContextListener {

  
	 public void contextInitialized(ServletContextEvent arg0)  { 
		 
		 System.out.println("In ContextInitialized Of CreateCardListener");
	    	
	    	
	    }
		

    public void contextDestroyed(ServletContextEvent arg0)  { 
    	
    	System.out.println("In ContextDestroyed Of CreateCardListener");
    }

	
   
}
