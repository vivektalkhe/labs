package com.cg.appl.filter;

import java.io.IOException;
import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


@WebFilter(dispatcherTypes = {DispatcherType.REQUEST }, urlPatterns = { "/AuthFilter", "*.do"})
public class AuthFilter implements Filter {

   
	
	public void init(FilterConfig fConfig) throws ServletException {
		
		System.out.println("In Filter-Init()");
	}
	
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		
		//before part
		System.out.println("In Filter-Before");
		chain.doFilter(request, response);
		//after part
		System.out.println("In Filter-After");
	}


	
public void destroy() {
		
		System.out.println("In Filter-Destroy()");
	}

}
