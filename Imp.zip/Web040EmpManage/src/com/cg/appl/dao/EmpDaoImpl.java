package com.cg.appl.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entites.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.JdbcUtil;

public class EmpDaoImpl implements EmpDao {
	
	private JdbcUtil util;

	public EmpDaoImpl() {
		
	util=new JdbcUtil();

	
	}

	@Override
	public Employee getEmpDetails(int empNo) throws EmpException {
		
		
		

		Connection connect=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
		String query="SELECT empno,ename,sal from emp where empno=?";
		try {
			connect=util.getConnection();
			stmt=connect.prepareStatement(query);
			stmt.setInt(1,empNo);
			rs=stmt.executeQuery();
			if(rs.next())
			{
				
				
				
				String empName=rs.getString("ename");
				
				float empSal=rs.getFloat("sal");
				Employee emp=new Employee(empNo,empName,empSal);
				return emp;
			}
			else
			{
				throw new EmpException("Employee Id Is Wrong");
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new EmpException("JDBC Fails",e);
		}
		
		finally
		{
		if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		
		if(stmt!=null)
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(connect!=null)
			try {
				connect.close();
			} catch (SQLException e) {
				throw new EmpException("Connection Closing Failed");
			}
		}
	}

}
