package com.cg.appl.dao;

import com.cg.appl.entites.Employee;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	
	Employee getEmpDetails(int empNo) throws EmpException;

}
