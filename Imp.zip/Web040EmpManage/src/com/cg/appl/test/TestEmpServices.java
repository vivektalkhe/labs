package com.cg.appl.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.entites.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpServices {
	
	private static EmpServices services;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		
		services=new EmpServicesImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
		services=null;
	}

	@Test
	public void testGetEmpDetails() {
		
		try {
			Employee expectedEmp=new Employee(7499,"ALLEN",5000);
			Employee actualEmp =services.getEmpDetails(7499);
			Assert.assertEquals(expectedEmp,actualEmp);
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*@Test(expected=EmpException.class)
	public void testGetExceptionOnWrongNo()
	{
		
		actualEmp =services.testGetExceptionOnWrongNo(7599);
	}*/
	
	
	
	
}
