package com.cg.appl.services;

import com.cg.appl.dao.EmpDao;
import com.cg.appl.dao.EmpDaoImpl;
import com.cg.appl.entites.Employee;
import com.cg.appl.exceptions.EmpException;

public class EmpServicesImpl implements EmpServices {
	
	
	private EmpDao dao;

	public EmpServicesImpl() {

	dao=new EmpDaoImpl();
	}
	

	public Employee getEmpDetails(int empNo) throws EmpException {
		
		return dao.getEmpDetails(empNo);
	}

}
