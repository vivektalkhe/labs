package com.cg.lab.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab.dto.UserMaster;
import com.cg.lab.exceptions.UserException;
import com.cg.lab.services.UserMasterService;
import com.cg.lab.services.UserMasterServicesImpl;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("/frontController")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterService services;
	
	public FrontController() {
		
		services=new UserMasterServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName=request.getParameter("fname");
		String lastName=request.getParameter("lname");
		String password=request.getParameter("pwd");
		String gender=request.getParameter("gender");
		
		String[] skill=request.getParameterValues("course");
		System.out.println(skill.length);

		String a="";
		
		if(skill!=null)
		{
		for(int i=0;i<skill.length;i++)
		{
			a+=skill[i].concat(",");	
		}
		}
		String city=request.getParameter("city");
		try {
			UserMaster user= new UserMaster(firstName,lastName,password,gender,a,city);
			
			services.addUser(user);
			request.setAttribute("empdata", user);
			RequestDispatcher dispatch=request.getRequestDispatcher("record");
			dispatch.forward(request, response);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			System.out.println("Adding User Not Successfully");
		}
	}
}