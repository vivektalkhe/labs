package com.cg.appl.servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.entities.User;
import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	String message=null;
	ServletContext ctx=null;
	
	
	public void init() throws ServletException {
		ctx=super.getServletContext();
		
		services=(UserMasterServices) ctx.getAttribute("services");
		
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String command=request.getServletPath();
		ctx.log("Command:"+command);
		
		switch(command)
		{
		
		
		case "/Login.do":
		{
			nextJsp="/Login.jsp";
			break;
		}
		
			 
		case "/authenticate.do" :
		{
			String username=request.getParameter("userName");
			String password=request.getParameter("password");
			System.out.println(username+" "+password);
			boolean isAuthenticated = false;
		
			
			try {
				
				
				isAuthenticated = services.isUserAuthenticated(username,password);
				System.out.println(isAuthenticated);
			if(isAuthenticated)
			{
				//System.out.println("Yes");
				//dispatch=request.getRequestDispatcher("/mainMenu.jsp");
				//dispatch.forward(request, resp);
				//start a session.
				
				
				
				
				
				User user=services.getUserDetails(username);
				HttpSession session=request.getSession(true);
				System.out.println(session.getId());
				session.setAttribute("user", user);
				nextJsp="/mainMenu.jsp";
				System.out.println("Suceessfully Login");
			}
			else 
			{
				
			//System.out.println("No");
			//dispatch=request.getRequestDispatcher("/Login.jsp");
			//dispatch.forward(request, resp);
				
				
				
				message="Wrong Credentials....Enter Again.........";
				request.setAttribute("ErrorMessage", message);
				nextJsp="/Login.jsp";
				System.out.println("No Login");
			}
			}
			catch (UserException e) {
				//System.out.println("NoT Authenticated");
				//dispatch=request.getRequestDispatcher("/Error.jsp");
				//dispatch.forward(request, resp);
				
				
				message="Username does not exist.....";
				request.setAttribute("ErrorMessage", message);
				ctx.log(e.getMessage());
				nextJsp="/Error.jsp";
				System.out.println("No Authenticated " + e);
				}
			break;
		}//enf of case for authenticate.do
		
		case "/Logout.do" :	{
			
			HttpSession session=request.getSession(false);
			session.invalidate();	//destroys a session.
			nextJsp="/Login.jsp";	
		}
		
	}
		dispatch=request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		processRequest(request,response);

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		processRequest(request,response);
	}

	public void destroy() {
		
		services=null;
	}
}
