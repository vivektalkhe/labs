package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.User;
import com.cg.appl.exception.UserException;
import com.cg.appl.util.JdbcUtil;
import com.cg.appl.util.JndiUtil;

public class UserMasterDaoImpl implements UserMasterDao {
	//private JdbcUtil util;
	private JndiUtil util;
	
	 public UserMasterDaoImpl() throws UserException {
		//util=new JdbcUtil();
		 util=new JndiUtil();
	}
	
	
	@Override
	public User getUserDetails(String userName) throws UserException {
		
		Connection connect=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
		String query="SELECT PASSWORD,USERFULLNAME FROM USERMASTER WHERE USERNAME=?";
		try {
			connect=util.getConnection();
			stmt=connect.prepareStatement(query);
			stmt.setString(1,userName);
			rs=stmt.executeQuery();
			if(rs.next())
			{
				//String userName=rs.getString("");
				String password=rs.getString("PASSWORD");
				String userFullName=rs.getString("USERFULLNAME");
				User user=new User(userName,password,userFullName);
				return user;
			}
			else
			{
				throw new UserException("UserName Wrong");
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new UserException("JDBC Fails",e);
		}
		
		finally
		{
		if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(stmt!=null)
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(connect!=null)
			try {
				connect.close();
			} catch (SQLException e) {
				throw new UserException("Connection Closing Failed");
			}
		}

	}

}
