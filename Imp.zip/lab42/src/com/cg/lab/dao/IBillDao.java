package com.cg.lab.dao;

import java.util.List;

import com.cg.lab.dto.BillDetails;
import com.cg.lab.dto.Consumer;
import com.cg.lab.exceptions.ElectricityExceptions;

public interface IBillDao {
	
	List<Consumer> showAll() throws ElectricityExceptions;
	int generateBillDetails(BillDetails bill) throws ElectricityExceptions;
	int getBillId() throws ElectricityExceptions;
	BillDetails showCustBillDetails(int cNum) throws ElectricityExceptions;

}
