package com.cg.lab.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.lab.dto.BillDetails;
import com.cg.lab.dto.Consumer;
import com.cg.lab.exceptions.ElectricityExceptions;
import com.cg.lab.util.JndiUtil;

public class BillDaoImpl implements IBillDao {

	private JndiUtil util = null;

	public BillDaoImpl() throws ElectricityExceptions {
		util = new JndiUtil();
	}

	public List<Consumer> showAll() throws ElectricityExceptions {

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String query = "Select consumer_num ,consumer_name,address from  Consumers";
		List<Consumer> empList = new ArrayList<Consumer>();

		try {
			conn = util.getConnection();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				Consumer cons = new Consumer();
				cons.setcNumber(rs.getInt("consumer_num"));
				cons.setcName(rs.getString("consumer_name"));
				cons.setcAddress(rs.getString("address"));
				empList.add(cons);
			}
		} catch (SQLException e) {
			System.out.println(e);
		} finally {

			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new ElectricityExceptions(e);
			}
		}
		return empList;
	}

	public int generateBillDetails(BillDetails bill)
			throws ElectricityExceptions {
		Connection conn = null;
		PreparedStatement ps = null;
		
		String query = "INSERT INTO BILLDETAILS(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(?,?,?,?,?,?)";
		int status = 0;
		int billNumber = getBillId();
		int billId = 0;
		try {
			conn = util.getConnection();
			ps = conn.prepareStatement(query);

			ps.setInt(1, billNumber);
			ps.setInt(2, bill.getConsumerNumber());
			ps.setDouble(3, bill.getCurrentReading());
			ps.setDouble(4, bill.getUnitsConsumed());
			ps.setDouble(5, bill.getNetAmount());
			ps.setDate(6,bill.getBill_date());
			status = ps.executeUpdate();
			if (status == 1) {
				billId = billNumber;
				System.out.println("Record inserted successfully.....");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return billId;
	}

	public int getBillId() throws ElectricityExceptions {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int billNumber = 0;
		try {
			conn = util.getConnection();
			ps = conn.prepareStatement("Select seq_bill_num.nextval from dual");
			rs = ps.executeQuery();
			while (rs.next()) {
				billNumber = rs.getInt(1);
			}
		} catch (ElectricityExceptions e) {
			// TODO Auto-generated catch block
			throw new ElectricityExceptions("Method of connection not called");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Sequence not created" + e);
		}

		finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new ElectricityExceptions("Connection Not closing", e);
			}
		}
		return billNumber;
	}

	@Override
	public BillDetails showCustBillDetails(int cNum) throws ElectricityExceptions {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String query = " select bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date from billdetails where consumer_num=?";
		BillDetails bill=new BillDetails();
		try {
			conn = util.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1,cNum);
			rs = ps.executeQuery();
			while(rs.next())
			{
				bill.setBillNumber(rs.getInt("bill_num"));
				bill.setConsumerNumber(rs.getInt("consumer_num"));
				bill.setCurrentReading(rs.getDouble("cur_reading"));
				bill.setUnitsConsumed(rs.getDouble("unitConsumed"));
				bill.setNetAmount(rs.getDouble("netAmount"));
				bill.setBill_date(rs.getDate("bill_date"));
				
			}
		} catch (SQLException e) {
			System.out.println("Data not Showing customer details"+e);
		}
		return bill;
	}
	
}
