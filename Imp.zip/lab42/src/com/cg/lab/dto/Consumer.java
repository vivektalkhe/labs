package com.cg.lab.dto;

public class Consumer {
	private int cNumber ;
	private String cName ;
	private String cAddress;
	
	public Consumer() {
		
		// TODO Auto-generated constructor stub
	}

	public Consumer(int cNumber, String cName, String cAddress) {
		super();
		this.cNumber = cNumber;
		this.cName = cName;
		this.cAddress = cAddress;
	}

	public int getcNumber() {
		return cNumber;
	}

	public void setcNumber(int cNumber) {
		this.cNumber = cNumber;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcAddress() {
		return cAddress;
	}

	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}

	@Override
	public String toString() {
		return "Consumer [cNumber=" + cNumber + ", cName=" + cName
				+ ", cAddress=" + cAddress + "]";
	}
	
	
	

}
