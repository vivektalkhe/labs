package com.cg.lab.dto;

import java.sql.Date;

import com.cg.lab.exceptions.ElectricityExceptions;

public class BillDetails {
	private int billNumber;
	private int ConsumerNumber;
	private double CurrentReading;
	private double unitsConsumed;
	private double netAmount;
	private Date bill_date = getDate();

	public BillDetails() {

		// TODO Auto-generated constructor stub
	}

	public BillDetails(int billNumber, int consumerNumber,
			double currentReading, double unitsConsumed, double netAmount) {
		super();
		this.billNumber = billNumber;
		this.ConsumerNumber = consumerNumber;
		this.CurrentReading = currentReading;
		this.unitsConsumed = unitsConsumed;
		this.netAmount = netAmount;

	}

	public BillDetails(int consumerNumber, double currentReading,
			double unitsConsumed, double netAmount) {
		super();

		this.ConsumerNumber = consumerNumber;
		this.CurrentReading = currentReading;
		this.unitsConsumed = unitsConsumed;
		this.netAmount = netAmount;

	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public int getConsumerNumber() {
		return ConsumerNumber;
	}

	public void setConsumerNumber(int consumerNumber) {
		ConsumerNumber = consumerNumber;
	}

	public double getCurrentReading() {
		return CurrentReading;
	}

	public void setCurrentReading(double currentReading) {
		CurrentReading = currentReading;
	}

	public double getUnitsConsumed() {
		return unitsConsumed;
	}

	public void setUnitsConsumed(double unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public Date getBill_date() {

		return bill_date;
	}

	public void setBill_date(Date bill_date) throws ElectricityExceptions {

		this.bill_date = bill_date;
	}

	public Date getDate() {
		Date today = java.sql.Date.valueOf(java.time.LocalDate.now());
		return today;

	}

	@Override
	public String toString() {
		return "BillDetails [billNumber=" + billNumber + ", ConsumerNumber="
				+ ConsumerNumber + ", CurrentReading=" + CurrentReading
				+ ", unitsConsumed=" + unitsConsumed + ", netAmount="
				+ netAmount + ", bill_date=" + bill_date + "]";
	}

}
