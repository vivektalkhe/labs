package com.cg.lab.services;

import java.util.List;

import com.cg.lab.dao.BillDaoImpl;
import com.cg.lab.dao.IBillDao;
import com.cg.lab.dto.BillDetails;
import com.cg.lab.dto.Consumer;
import com.cg.lab.exceptions.ElectricityExceptions;

public class BillServiceImpl implements IBillService {

	private IBillDao dao;
	public BillServiceImpl() throws ElectricityExceptions {
		dao=new BillDaoImpl();
		
	}

	@Override
	public List<Consumer> showAll() throws ElectricityExceptions {
	
		return dao.showAll();
	}

	@Override
	public int generateBillDetails(BillDetails bill)
			throws ElectricityExceptions {
		
		return dao.generateBillDetails(bill);
	}

	@Override
	public BillDetails showCustBillDetails(int cNum)
			throws ElectricityExceptions {
		// TODO Auto-generated method stub
		return dao.showCustBillDetails(cNum);
	}

}
