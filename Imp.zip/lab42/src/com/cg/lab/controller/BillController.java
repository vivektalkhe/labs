package com.cg.lab.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.lab.dto.BillDetails;
import com.cg.lab.dto.Consumer;
import com.cg.lab.exceptions.ElectricityExceptions;
import com.cg.lab.services.BillServiceImpl;
import com.cg.lab.services.IBillService;

/**
 * Servlet implementation class BillController
 */
@WebServlet("*.do")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IBillService services;
      

	public void init(ServletConfig config) throws ServletException {
		try {
			services=new BillServiceImpl();
		} catch (ElectricityExceptions e) {
			// TODO Auto-generated catch block
			System.out.println("Services Object Not created");
		}
	}

	protected void doProcessRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ElectricityExceptions
	{ 
		String path=request.getServletPath();
		HttpSession session = request.getSession(true);
		System.out.println(path);
		if(path.equals("/consumer.do"))
		{
			
			try {
				List<Consumer> clist=services.showAll();
				System.out.println(clist);
				session.setAttribute("ConsumerData",clist);
				RequestDispatcher req=request.getRequestDispatcher("showConsumer.jsp");
				req.forward(request, response);
			} catch (ElectricityExceptions e) {
				// TODO Auto-generated catch block
			System.out.println("Show ALL MEthod not called In Controller");
			}
		}
		if(path.equals("/generateBill.do"))
		{
			RequestDispatcher req=request.getRequestDispatcher("bill.jsp");
			req.forward(request, response);
		}
		if(path.equals("/generate.do"))
		{
			int cNumber=Integer.parseInt(request.getParameter("cNumber"));
			double cReading=Double.parseDouble(request.getParameter("cReading"));
			double cLastdReading=Double.parseDouble(request.getParameter("clReading"));
			double units=cReading-cLastdReading;
			double perUnitsPrice=1.15;
			int fixedCharge=100;
			double netAmount=units*perUnitsPrice+fixedCharge;
			
			BillDetails bill=new BillDetails(cNumber,cReading,units,netAmount);
			
			try {
				int id=services.generateBillDetails(bill);
				System.out.println(bill);
				System.out.println(id);
				bill=services.showCustBillDetails(cNumber);
				System.out.println(bill);
				session.setAttribute("consumerNumber",cNumber);
				session.setAttribute("amount", netAmount);
				session.setAttribute("units", units);
				RequestDispatcher req=request.getRequestDispatcher("billDetails.jsp");
				req.forward(request, response);
				
			} catch (ElectricityExceptions e) {
				// TODO Auto-generated catch block
				throw new ElectricityExceptions("Method of insertion not called in controller");
			}
		}
		
	}
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	try {
		doProcessRequest(request, response);
	} catch (ElectricityExceptions e) {
		// TODO Auto-generated catch block
		System.out.println("Problem in Get");
	}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			doProcessRequest(request, response);
		} catch (ElectricityExceptions e) {
			// TODO Auto-generated catch block
			System.out.println("Problem in post");
		}
	}
	public void destroy() {
		services=null;
	}

}
