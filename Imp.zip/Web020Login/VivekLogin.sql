select * from emp;

create table usermaster
(username varchar2(15) primary key,
password varchar2(15),
userfullname varchar2(30)
);

insert into usermaster (USERNAME,PASSWORD,USERFULLNAME) values ('a','a','Vivek');

insert into usermaster (USERNAME,PASSWORD,USERFULLNAME) values ('b','b','Nikhil');

select * from USERMASTER;
