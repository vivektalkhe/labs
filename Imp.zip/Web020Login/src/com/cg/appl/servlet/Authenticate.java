package com.cg.appl.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;

	public void init() throws ServletException {
		services=new UserMasterServicesImpl();
		
	}
		
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String username=request.getParameter("userName");
		String password=request.getParameter("password");
		System.out.println(username+" "+password);
		boolean isAuthenticated = false;
		RequestDispatcher dispatch=null;
		String nextjsp=null;
		String message=null;
		
		try {
			isAuthenticated = services.isUserAuthenticated(username,password);
		
		if(isAuthenticated)
		{
			//System.out.println("Yes");
			//dispatch=request.getRequestDispatcher("/mainMenu.jsp");
			//dispatch.forward(request, resp);
			nextjsp="/mainMenu.jsp";
		}
		else 
		{
		//System.out.println("No");
		//dispatch=request.getRequestDispatcher("/Login.jsp");
		//dispatch.forward(request, resp);
			message="Wrong Credentials....Enter Again.........";
			request.setAttribute("ErrorMessage", message);
			nextjsp="/Login.jsp";
		}
		}
		catch (UserException e) {
			//System.out.println("NoT Authenticated");
			
			//dispatch=request.getRequestDispatcher("/Error.jsp");
			//dispatch.forward(request, resp);
			
			message="Username does not exist.....";
			request.setAttribute("ErrorMessage", message);

			nextjsp="/Error.jsp";
			}
		dispatch=request.getRequestDispatcher(nextjsp);
		dispatch.forward(request, resp);
	}

	public void destroy() {
		
				
		
	}

}