package com.cg.appl.junits;

import static org.junit.Assert.*;

import com.cg.appl.entities.User;
import com.cg.appl.exception.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

import org.junit.BeforeClass;
import org.junit.Test;



public class TestUser {
	
	private static UserMasterServices services;

	@BeforeClass
	public static void initialize()
	
	{
		services=new UserMasterServicesImpl();
	}


	@Test
	public void testGetUserDetails() throws Exception {

	try {
		

		User user=services.getUserDetails("a");
		String actualPassword="a";
		assertEquals(user.getPassword(),actualPassword);
			
	} catch (UserException e) {
		e.printStackTrace();
	}
	}

}
