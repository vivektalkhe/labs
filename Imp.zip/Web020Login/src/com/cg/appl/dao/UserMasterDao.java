package com.cg.appl.dao;



import com.cg.appl.entities.User;
import com.cg.appl.exception.UserException;

public interface UserMasterDao {
	
	
User getUserDetails(String userName) throws UserException;
}
