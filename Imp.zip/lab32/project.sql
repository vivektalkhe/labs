create table RegUser
(firstname varchar2(50),
lastname varchar2(50),
password varchar2(50),
gender varchar2(1),
skill varchar2(50),
city varchar2(50));

select * from RegUser; 