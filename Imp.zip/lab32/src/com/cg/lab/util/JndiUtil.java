package com.cg.lab.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.lab.exceptions.UserException;

public class JndiUtil {
	private DataSource datasource; 
	
	public JndiUtil() throws UserException {
		
		try {
			Context ctx = new InitialContext();  //Get Reference To Remote JNDI 
			datasource =(DataSource) ctx.lookup("java:/OracleDS");
			System.out.println("Connected");
 		} catch (NamingException e) {
			// TODO Auto-generated catch block
		
			throw new UserException("Failed To Get JNDI Context",e);
		}
	
		
	}
	public Connection getConnection() throws SQLException {
		return datasource.getConnection();

	}
	
	
	
		
	
	
}
