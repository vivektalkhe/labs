package com.cg.lab.dao;

import com.cg.lab.dto.UserMaster;
import com.cg.lab.exceptions.UserException;

public interface UserMasterDao {
	
	UserMaster addUser(UserMaster user) throws UserException;
}
