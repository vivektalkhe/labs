package com.cg.lab.dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;




import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.cg.lab.dto.UserMaster;
import com.cg.lab.exceptions.UserException;
import com.cg.lab.util.JndiUtil;
import com.ibm.wsdl.util.StringUtils;


public class UserMasterDaoImpl implements UserMasterDao {

private  JndiUtil util=null;
	public UserMasterDaoImpl() {
		try {
			util=new JndiUtil();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Connected To Database");
		}
		
	}

	@Override
	public UserMaster addUser(UserMaster user) throws UserException {
		try {
			Connection conn=util.getConnection();
			String query="Insert into RegUser(firstname ,lastname ,password ,gender ,skill,city) values(?,?,?,?,?,?)";
			PreparedStatement ps;
			//Array array=ps.getConnection().createArrayOf("Varchar2", );
			ps=conn.prepareStatement(query);
			ps.setString(1,user.getFirstName());
			ps.setString(2,user.getLastName());
			ps.setString(3,user.getPassword());
			ps.setString(4,user.getGender());
			String skill=user.getSkill();
			
			
			
			ps.setString(5,skill);
			
			
			
			ps.setString(6,user.getCity());
			
			int add=ps.executeUpdate();
			if(add==1)
			{
				System.out.println("Record Inserted Successfully");
				
			}
			else
			{
				throw new UserException("record is not instered");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		return user;
	}

	
}
