package com.cg.lab.services;

import com.cg.lab.dao.UserMasterDao;
import com.cg.lab.dao.UserMasterDaoImpl;
import com.cg.lab.dto.UserMaster;
import com.cg.lab.exceptions.UserException;

public class UserMasterServicesImpl implements UserMasterService {

	private UserMasterDao dao;
	
	public UserMasterServicesImpl() {
		dao=new UserMasterDaoImpl();
		
	}

	@Override
	public UserMaster addUser(UserMaster user) throws UserException {
	
		return dao.addUser(user);
	}

}
