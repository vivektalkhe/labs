package com.cg.lab.services;

import com.cg.lab.dto.UserMaster;
import com.cg.lab.exceptions.UserException;

public interface UserMasterService {
	UserMaster addUser(UserMaster user) throws UserException;
}
