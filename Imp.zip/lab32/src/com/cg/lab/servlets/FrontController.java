package com.cg.lab.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab.dto.UserMaster;
import com.cg.lab.exceptions.UserException;
import com.cg.lab.services.UserMasterService;
import com.cg.lab.services.UserMasterServicesImpl;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("/frontController")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterService services;
	
	public FrontController() {
		
		services=new UserMasterServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName=request.getParameter("fname");
		String lastName=request.getParameter("lname");
		String password=request.getParameter("pwd");
		String gender=request.getParameter("gender");
		
		String[] skill=request.getParameterValues("course");
		System.out.println(skill.length);
		
	
		String a="";
		String b=",";
		if(skill!=null)
		{
		for(int i=0;i<skill.length;i++)
		{
			a+=skill[i]+",";
			
				

			
			
		}
		}
		String city=request.getParameter("city");
		
		UserMaster user= new UserMaster(firstName,lastName,password,gender,a,city);
		
		try {
			services.addUser(user);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			System.out.println("Adding User Not Successfully");
		}
		
	}

}
