package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/anotherServlet")
public class AnotherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private float rateInterest;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletContext ctx=super.getServletContext();
		String rateInterestStr=ctx.getInitParameter("rateInterest");
		rateInterest=Float.parseFloat(rateInterestStr);
		System.out.println("From Service():"+rateInterest);
		ServletConfig cfg=super.getServletConfig();
		String xstr=cfg.getInitParameter("x");
		int x=Integer.parseInt(xstr);
		System.out.println(x);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
	}

}
